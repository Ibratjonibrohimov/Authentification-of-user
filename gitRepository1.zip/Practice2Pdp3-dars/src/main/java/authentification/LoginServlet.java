package authentification;

import databaseService.DatabaseService;
import model.Result;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.PrintWriter;

public class LoginServlet extends HttpServlet {

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        resp.sendRedirect("login.html");
    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        String username=req.getParameter("username");
        String password=req.getParameter("password");
        DatabaseService databaseService=new DatabaseService();
        Result result = databaseService.loginUser(username, password);
        PrintWriter writer = resp.getWriter();
        resp.setContentType("text/html");

        if (result.isCheck()) {
            writer.println("<h1 color='green'>" + result.getResult() + "</h1>");
        } else {
            resp.sendRedirect("erorLogin.html");
        }
    }
}
