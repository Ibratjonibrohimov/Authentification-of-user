package authentification;

import databaseService.DatabaseService;
import model.Result;
import model.User;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.PrintWriter;

public class RegisterServlet extends HttpServlet {
    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        resp.sendRedirect("register.html");
    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        String firstName = req.getParameter("first_name");
        String lastName = req.getParameter("last_name");
        String userName = req.getParameter("username");
        String phoneNumber = req.getParameter("phoneNumber");
        String password = req.getParameter("password");
        String prePassword = req.getParameter("prePassword");
        PrintWriter writer = resp.getWriter();
        resp.setContentType("text/html");
        if (password.equals(prePassword)) {
            User user = new User(firstName, lastName, userName, phoneNumber, password);
            DatabaseService databaseService = new DatabaseService();

                Result result = databaseService.registerUser(user);

                if (result.isCheck()) {
                    writer.println("<h1 color='green'>" + result.getResult() + "</h1>");

                } else {
                    writer.println("<h1 color='red'>" + result.getResult() + "</h1>");
                }
        }else{
                writer.println("<h1 color='red'>Password is not equal prepassword</h1>");
            }

    }
}
