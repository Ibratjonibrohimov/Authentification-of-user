package databaseService;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import model.Result;
import model.User;

import java.sql.*;

@Data
@AllArgsConstructor
@NoArgsConstructor

public class DatabaseService {

    private String url="jdbc:postgresql://localhost:5432/practice3";

    private String dbUser="postgres";
    private String dbPassword="p@ssw0rd";
    public Result registerUser(User user)  {

        try{
            Class.forName("org.postgresql.Driver");

            Connection connection= DriverManager.getConnection(url,dbUser,dbPassword);

            String queryPhone="select count(id) from users where phone_number=?";

            PreparedStatement preparedStatement1=connection.prepareStatement(queryPhone);

            preparedStatement1.setString(1,user.getPhoneNumber());
            ResultSet resultSet = preparedStatement1.executeQuery();
            int countFields=0;
            while(resultSet.next()){
                countFields=resultSet.getInt(1);
            }
            if(countFields>0){
                return new Result("This phone number is already registered",false);
            }
            String queryUser="select count(id) from users where user_name=?;";
            PreparedStatement preparedStatement2=connection.prepareStatement(queryUser);
            preparedStatement2.setString(1,user.getUserName());
            ResultSet resultSet1 = preparedStatement2.executeQuery();
            while(resultSet1.next()){
                countFields=resultSet1.getInt(1);
            }
            if(countFields>0){
                return new Result("This username is already registered",false);
            }
            String addUser="insert into users(first_name,last_name,user_name,password,phone_number) values(?,?,?,?,?);";
            PreparedStatement preparedStatement3=connection.prepareStatement(addUser);
            preparedStatement3.setString(1,user.getFirstName());
            preparedStatement3.setString(2,user.getLastName());
            preparedStatement3.setString(3,user.getUserName());
            preparedStatement3.setString(4,user.getPassword());
            preparedStatement3.setString(5,user.getPhoneNumber());
            preparedStatement3.execute();
            return new Result("Yuo are registered successfully",true);
        } catch (SQLException e) {
            e.printStackTrace();
            return new Result("Error in server", false);
        } catch (ClassNotFoundException e) {
            throw new RuntimeException(e);
        }
    }
    public Result loginUser(String username,String password){
        try{
            Class.forName("org.postgresql.Driver");
            Connection connection=DriverManager.getConnection(url,dbUser,dbPassword);
            String query="select count(id) from users where user_name=? and password=?;";
            PreparedStatement preparedStatement=connection.prepareStatement(query);
            preparedStatement.setString(1,username);
            preparedStatement.setString(2,password);
            ResultSet resultSet = preparedStatement.executeQuery();
            int countFiled=0;
            while (resultSet.next()){
                countFiled=resultSet.getInt(1);
            }
            if(countFiled==0){
                return new Result("You don't exist in our list. Please register",false);
            }
            else{
                return new Result("Welcome to Program",true);
            }
        } catch (ClassNotFoundException e) {
            throw new RuntimeException(e);
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return new Result("Eror in server",false);
    }
}
