package org.example;

import java.util.*;


public class Main {
    public static void main(String[] args) {
        Stack<Integer> stack=new Stack<>();
        stack.add(11);
    }

}